/* ─── ARIA Chatbot — Frontend Script ─────────────────────────── */

let isWaiting = false;
let ttsEnabled = true;

// ─── Send Message ────────────────────────────────────────────────

async function sendMessage() {
  const input = document.getElementById('userInput');
  const msg = input.value.trim();
  if (!msg || isWaiting) return;

  clearWelcome();
  appendMessage('user', msg);
  input.value = '';
  autoResize(input);

  setWaiting(true);

  try {
    const res = await fetch('/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: msg })
    });

    const data = await res.json();

    setWaiting(false);

    if (data.error && !data.response) {
      appendMessage('bot', '⚠️ ' + data.error, null, null);
      return;
    }

    appendMessage('bot', data.response, data.intent, data.sentiment, data.timestamp);
    updateSentimentBadge(data.sentiment);

    if (ttsEnabled && data.response) {
      speakText(data.response);
    }

  } catch (err) {
    setWaiting(false);
    appendMessage('bot', '⚠️ Connection error. Is the Flask server running?', null, null);
  }
}

function sendQuick(text) {
  document.getElementById('userInput').value = text;
  sendMessage();
}

// ─── Voice Input ─────────────────────────────────────────────────

async function startVoice() {
  if (isWaiting) return;

  const micBtn = document.getElementById('micBtn');
  micBtn.classList.add('listening');
  micBtn.title = 'Listening...';

  clearWelcome();
  appendMessage('bot', '🎤 Listening... Speak now!', null, null);

  try {
    const res = await fetch('/voice', { method: 'POST' });
    const data = await res.json();

    micBtn.classList.remove('listening');
    micBtn.title = 'Voice Input';

    // Remove listening message
    const msgs = document.querySelectorAll('.msg-row');
    if (msgs.length > 0) {
      const last = msgs[msgs.length - 1];
      if (last.querySelector('.bubble').textContent.includes('Listening')) {
        last.remove();
      }
    }

    if (data.error) {
      appendMessage('bot', '⚠️ ' + data.error, null, null);
      return;
    }

    appendMessage('user', '🎤 ' + data.recognized_text);
    appendMessage('bot', data.response, data.intent, data.sentiment, data.timestamp);
    updateSentimentBadge(data.sentiment);

  } catch (err) {
    micBtn.classList.remove('listening');
    micBtn.title = 'Voice Input';
    appendMessage('bot', '⚠️ Voice feature unavailable. Check server connection.', null, null);
  }
}

// ─── TTS ─────────────────────────────────────────────────────────

async function speakText(text) {
  try {
    await fetch('/speak', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
  } catch (e) { /* TTS optional */ }
}

// ─── Clear Chat ───────────────────────────────────────────────────

async function clearChat() {
  try {
    await fetch('/clear', { method: 'POST' });
  } catch (e) {}

  const chatWindow = document.getElementById('chatWindow');
  chatWindow.innerHTML = `
    <div class="welcome-msg">
      <div class="welcome-orb"><span>🤖</span></div>
      <h2>Hello, I'm ARIA</h2>
      <p>Your intelligent AI companion. Ask me anything — I can chat, solve math, detect emotions, and remember our conversation.</p>
      <div class="quick-btns">
        <button class="quick-btn" onclick="sendQuick('What can you do?')">What can you do?</button>
        <button class="quick-btn" onclick="sendQuick('Solve 125 * 48')">Solve 125 * 48</button>
        <button class="quick-btn" onclick="sendQuick('Help')">Show Help</button>
        <button class="quick-btn" onclick="sendQuick('My name is Alex')">Set My Name</button>
      </div>
    </div>
  `;

  document.getElementById('sentimentBadge').className = 'sentiment-badge hidden';
}

// ─── DOM Helpers ──────────────────────────────────────────────────

function clearWelcome() {
  const welcome = document.querySelector('.welcome-msg');
  if (welcome) welcome.remove();
}

function appendMessage(role, text, intent, sentiment, time) {
  const chatWindow = document.getElementById('chatWindow');

  const row = document.createElement('div');
  row.className = `msg-row ${role}`;

  const avatar = document.createElement('div');
  avatar.className = 'msg-avatar';
  avatar.textContent = role === 'user' ? 'YOU' : 'AI';

  const content = document.createElement('div');
  content.className = 'msg-content';

  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  bubble.innerHTML = formatText(text);

  const meta = document.createElement('div');
  meta.className = 'msg-meta';

  if (time) {
    const timeSpan = document.createElement('span');
    timeSpan.textContent = time;
    meta.appendChild(timeSpan);
  }

  if (intent && role === 'bot') {
    const tag = document.createElement('span');
    tag.className = 'intent-tag';
    tag.textContent = intent;
    meta.appendChild(tag);
  }

  content.appendChild(bubble);
  if (meta.children.length > 0 || time) content.appendChild(meta);

  row.appendChild(avatar);
  row.appendChild(content);
  chatWindow.appendChild(row);

  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function formatText(text) {
  // Convert markdown-ish to HTML
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/`(.*?)`/g, '<code>$1</code>')
    .replace(/\n/g, '<br>')
    .replace(/•\s/g, '• ')
    .replace(/^• (.+)$/gm, '• $1');
}

function setWaiting(state) {
  isWaiting = state;
  const typingBar = document.getElementById('typingBar');
  const sendBtn = document.getElementById('sendBtn');
  typingBar.style.display = state ? 'flex' : 'none';
  sendBtn.disabled = state;
  sendBtn.style.opacity = state ? '0.5' : '1';

  const chatWindow = document.getElementById('chatWindow');
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function updateSentimentBadge(sentiment) {
  const badge = document.getElementById('sentimentBadge');
  if (!sentiment) return;
  const icons = { positive: '😊', negative: '😟', neutral: '😐' };
  badge.textContent = `${icons[sentiment] || '😐'} ${sentiment}`;
  badge.className = `sentiment-badge ${sentiment}`;
}

function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 120) + 'px';
}

function handleKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
}

// ─── Init ─────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('userInput').focus();
});
