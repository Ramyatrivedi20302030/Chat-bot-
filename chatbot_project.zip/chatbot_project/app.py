from flask import Flask, request, jsonify, render_template, session
from datetime import datetime
import uuid
import json

from chatbot_core import get_response
from intent_detection import detect_intent, extract_entities
from chatbot_core import detect_sentiment
from database import init_db, save_conversation, get_analytics
from voice_assistant import speak, listen

app = Flask(__name__)
app.secret_key = "aria_secret_key_2024_hackathon"

# Initialize database on startup
try:
    init_db()
except Exception:
    print("[WARN] DB init skipped — running without database.")

def get_session_id():
    if "session_id" not in session:
        session["session_id"] = str(uuid.uuid4())
    return session["session_id"]

# ─── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    try:
        data = request.get_json()
        if not data or "message" not in data:
            return jsonify({"error": "No message provided"}), 400

        user_message = data["message"].strip()
        if not user_message:
            return jsonify({"error": "Empty message"}), 400

        session_id = get_session_id()
        intent = detect_intent(user_message)
        entities = extract_entities(user_message)
        sentiment = detect_sentiment(user_message)

        bot_response = get_response(user_message, session_id)

        # Save to DB (non-blocking, ignore failure)
        try:
            save_conversation(session_id, user_message, bot_response, intent, sentiment)
        except Exception:
            pass

        return jsonify({
            "response": bot_response,
            "intent": intent,
            "entities": entities,
            "sentiment": sentiment,
            "timestamp": datetime.now().strftime("%I:%M %p")
        })

    except Exception as e:
        print(f"[CHAT ERROR] {e}")
        return jsonify({"response": "⚠️ Something went wrong. Please try again.", "error": str(e)}), 500

@app.route("/voice", methods=["POST"])
def voice_input():
    try:
        text = listen()
        if text:
            session_id = get_session_id()
            bot_response = get_response(text, session_id)
            intent = detect_intent(text)
            sentiment = detect_sentiment(text)

            try:
                save_conversation(session_id, text, bot_response, intent, sentiment)
            except Exception:
                pass

            # Speak response in background
            speak(bot_response)

            return jsonify({
                "recognized_text": text,
                "response": bot_response,
                "intent": intent,
                "sentiment": sentiment,
                "timestamp": datetime.now().strftime("%I:%M %p")
            })
        else:
            return jsonify({"error": "Could not recognize speech. Please try again."}), 400

    except Exception as e:
        print(f"[VOICE ERROR] {e}")
        return jsonify({"error": f"Voice error: {str(e)}"}), 500

@app.route("/speak", methods=["POST"])
def tts_speak():
    """Trigger TTS for a given text."""
    try:
        data = request.get_json()
        text = data.get("text", "")
        if text:
            speak(text)
        return jsonify({"status": "speaking"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/clear", methods=["POST"])
def clear_chat():
    try:
        from memory import ConversationMemory
        from chatbot_core import memory
        session_id = get_session_id()
        memory.clear(session_id)
        session.pop("session_id", None)
        return jsonify({"status": "cleared", "message": "Conversation history cleared."})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/analytics")
def analytics():
    return render_template("analytics.html")

@app.route("/analytics/data")
def analytics_data():
    try:
        data = get_analytics()
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ─── Run ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 55)
    print("  🤖  ARIA - AI Chatbot Server Starting...")
    print("=" * 55)
    print("  Chat UI   →  http://127.0.0.1:5000")
    print("  Analytics →  http://127.0.0.1:5000/analytics")
    print("=" * 55)
    app.run(debug=True, host="0.0.0.0", port=5000)
