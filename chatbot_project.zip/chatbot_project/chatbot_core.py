"""
chatbot_core.py — ARIA Core Response Engine
Upgraded with Data Structures Tutor capability.
Priority: DS questions -> Math -> Small Talk -> General AI
"""

import re
import json
import random
import math
from datetime import datetime
from intent_detection import detect_intent, extract_entities
from memory import ConversationMemory
from ds_engine import get_ds_answer, get_topic_list, is_ds_question

memory = ConversationMemory()

SMALL_TALK = {
    "hello": [
        "Hey there! 👋 I'm ARIA, your Data Structures tutor. Ask me about arrays, trees, sorting, or any DS topic!",
        "Hello! Ready to learn some Data Structures? Ask me anything! 🚀",
        "Hi! I'm ARIA — your AI tutor for Data Structures & Algorithms. What shall we explore today?"
    ],
    "how are you": [
        "Running at O(1) efficiency! 😄 Ready to help you master Data Structures!",
        "I'm doing great! Let's dive into some Data Structures — what topic interests you?",
        "All systems operational! Ask me about any DS topic! 📚"
    ],
    "bye": ["Goodbye! Keep practicing DSA! 👋", "See you! Come back to practice Data Structures anytime!", "Farewell! Remember: consistent practice = mastery! 💪"],
    "thanks": ["You're welcome! 😊 Keep learning!", "Happy to help with your DS studies!", "Anytime! Data Structures become easy with practice! 🎯"],
    "who are you": [
        "I'm ARIA — Advanced Reasoning & Intelligence Assistant, upgraded to be your **Data Structures Tutor**! I explain arrays, trees, graphs, sorting, complexity, and much more! 🤖📚",
    ],
    "what can you do": [
        "I'm your **DS Tutor**! Here's what I can do:\n\n• 📚 **Data Structures** — Arrays, Linked Lists, Trees, Graphs, Hash Tables, Heaps, Stacks, Queues\n• 🔀 **Algorithms** — Sorting, Searching, BFS, DFS, Dijkstra\n• ⏱️ **Complexity** — Big-O, Time & Space complexity\n• 🧩 **Advanced** — Dynamic Programming, Greedy Algorithms, Recursion\n• 🧮 **Math** — Solve math expressions too!\n\nTry: 'What is a BST?' or 'Explain merge sort'"
    ],
}

HELP_TEXT = """
📚 **ARIA — Data Structures Tutor**

**Data Structures:**
• `what is array / linked list / stack / queue`
• `explain binary tree / BST / AVL tree`
• `what is hash table / heap / trie / deque`

**Algorithms:**
• `what is bubble sort / merge sort / quick sort / heap sort`
• `explain binary search / linear search`
• `what is BFS / DFS` — `difference between BFS and DFS`

**Complexity:**
• `what is time complexity / space complexity`
• `what is big o notation` — `complexity cheat sheet`

**Advanced:**
• `what is dynamic programming / greedy algorithm`
• `explain recursion / fibonacci / knapsack / LCS`
• `what is Dijkstra / topological sort / MST`

**Commands:**
• `topics` — List all DS topics
• `help` — This menu
• `my name is <n>` — Personalize session
• `show history` — Recent chat history
• `clear memory` — Reset session

**Tip:** Ask naturally! "Explain merge sort", "difference BFS DFS", "when to use heap?" all work!
"""

SENTIMENT_KEYWORDS = {
    "positive": ["happy", "great", "awesome", "love", "excellent", "fantastic", "good", "wonderful", "amazing", "joy", "excited", "understood", "clear", "easy", "learned", "got it"],
    "negative": ["sad", "bad", "hate", "terrible", "awful", "angry", "frustrated", "upset", "horrible", "confused", "hard", "difficult", "stuck", "lost", "dont understand", "don't understand"],
    "neutral": []
}

def detect_sentiment(text):
    text_lower = text.lower()
    pos = sum(1 for w in SENTIMENT_KEYWORDS["positive"] if w in text_lower)
    neg = sum(1 for w in SENTIMENT_KEYWORDS["negative"] if w in text_lower)
    if pos > neg: return "positive"
    elif neg > pos: return "negative"
    return "neutral"

def solve_math(expression):
    try:
        clean = re.sub(r'[^0-9+\-*/().% ]', '', expression)
        clean = clean.replace('%', '/100')
        result = eval(clean, {"__builtins__": {}, "math": math})
        return f"🧮 The answer is: **{result}**"
    except Exception:
        return None

ENCOURAGEMENTS = [
    "💡 Great question! This is key for coding interviews!",
    "🎯 This is commonly asked in technical interviews!",
    "✨ Mastering this will make you a stronger programmer!",
    "🚀 Fundamental concept — you're on the right track!"
]

def get_response(user_message, session_id="default"):
    msg = user_message.strip()
    msg_lower = msg.lower()

    if msg_lower in ["help", "/help", "?", "commands"]:
        return HELP_TEXT

    if msg_lower in ["topics", "list topics", "all topics", "what topics", "show topics"]:
        return get_topic_list()

    name_match = re.search(r"my name is (\w+)", msg_lower)
    if name_match:
        name = name_match.group(1).capitalize()
        memory.set_user_name(session_id, name)
        return f"Nice to meet you, **{name}**! 😊 Ready to study Data Structures? Try: 'What is a stack?' or 'Explain merge sort'!"

    user_name = memory.get_user_name(session_id)

    if "show history" in msg_lower or "my history" in msg_lower:
        hist = memory.get_history(session_id)
        if not hist:
            return "No history yet. Start learning! Try: 'What is an array?'"
        lines = [f"**You:** {h['user']}\n**ARIA:** {h['bot'][:120]}..." for h in hist[-5:]]
        return "📜 **Recent History:**\n\n" + "\n\n---\n\n".join(lines)

    if msg_lower in ["clear memory", "forget me", "reset"]:
        memory.clear(session_id)
        return "Memory cleared! Fresh start. 🧹 Ready to learn Data Structures?"

    math_patterns = [r'\d+\s*[\+\-\*/\^%]\s*\d+', r'(calculate|solve|compute)\s+[\d\s\+\-\*/\(\)\.]+']
    for pattern in math_patterns:
        if re.search(pattern, msg_lower):
            math_expr = re.sub(r'(calculate|solve|compute|the answer to|=\?)', '', msg_lower).strip()
            result = solve_math(math_expr)
            if result:
                memory.add(session_id, msg, result)
                return result

    # ★ DATA STRUCTURES ENGINE ★
    ds_answer = get_ds_answer(msg)
    if ds_answer:
        if random.random() < 0.30:
            ds_answer = random.choice(ENCOURAGEMENTS) + "\n\n" + ds_answer
        if user_name:
            ds_answer = f"Here you go, **{user_name}**! 📖\n\n" + ds_answer
        memory.add(session_id, msg, ds_answer)
        return ds_answer

    for key, responses in SMALL_TALK.items():
        if key in msg_lower:
            response = random.choice(responses)
            memory.add(session_id, msg, response)
            return response

    sentiment = detect_sentiment(msg)
    if sentiment == "negative":
        response = generate_study_support_response(msg, user_name)
        memory.add(session_id, msg, response)
        return response

    intent = detect_intent(msg)
    response = generate_contextual_response(msg, intent, sentiment, user_name)
    memory.add(session_id, msg, response)
    return response

def generate_study_support_response(msg, user_name):
    name_prefix = f"Don't worry, **{user_name}**! " if user_name else "Don't worry! "
    options = [
        f"{name_prefix}Data Structures can seem tricky at first, but you'll get it! 💪\n\nStart with basics:\n• `What is an array?`\n• `What is a stack?`\n• `What is time complexity?`",
        f"{name_prefix}Everyone struggles at first — it's normal! 🤗\n\nAsk me about any confusing topic: `Explain <topic>`",
        f"{name_prefix}You're here and learning — that's what matters! 🌟\n\nTell me what's confusing and I'll break it down simply.",
    ]
    return random.choice(options)

def generate_contextual_response(msg, intent, sentiment, user_name):
    name_prefix = f"{user_name}, " if user_name else ""
    nudges = [
        f"{name_prefix}I'm specialized as a **Data Structures tutor**! 📚 Ask me about arrays, trees, sorting, BFS, DFS, or complexity analysis.\n\nTry: `What is a BST?` or `Explain merge sort`",
        f"{name_prefix}Not sure I caught that. I'm best at **Data Structures & Algorithms** questions. 🎯\n\nTopics: Arrays, Linked Lists, Trees, Graphs, Sorting, Searching, Big-O...\n\nWhat would you like to learn?",
        f"{name_prefix}I'm your DS tutor! 🤖 Could you rephrase? Or type `help` to see all I can do!",
    ]
    if intent == "greeting":
        return f"Hello{', ' + user_name if user_name else ''}! 👋 Ready to study Data Structures? Type `topics` to see all available topics!"
    return random.choice(nudges)
