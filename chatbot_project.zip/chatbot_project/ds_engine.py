"""
ds_engine.py — Data Structures Knowledge Engine
Handles keyword matching, cosine similarity, and NLP preprocessing
for intelligent Data Structures Q&A matching.
"""

import json
import re
import os
import math
from collections import Counter

# ─── Load Knowledge Base ──────────────────────────────────────────────────────

_KB_PATH = os.path.join(os.path.dirname(__file__), "ds_knowledge.json")

def _load_kb():
    try:
        with open(_KB_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"[DS Engine] Could not load ds_knowledge.json: {e}")
        return []

KNOWLEDGE_BASE = _load_kb()

# ─── Stopwords ────────────────────────────────────────────────────────────────

STOPWORDS = {
    "what", "is", "are", "the", "a", "an", "how", "does", "do",
    "explain", "define", "tell", "me", "about", "can", "you",
    "please", "describe", "meaning", "of", "in", "and", "or",
    "it", "its", "to", "with", "for", "from", "give", "show",
    "i", "want", "know", "need", "why", "when", "where", "which"
}

# ─── DS Topic Keywords ────────────────────────────────────────────────────────

DS_TRIGGER_WORDS = {
    "array", "arrays", "linked", "list", "stack", "queue", "tree",
    "binary", "bst", "graph", "hash", "heap", "trie", "deque",
    "recursion", "recursive", "sorting", "sort", "search", "searching",
    "bfs", "dfs", "breadth", "depth", "traversal", "inorder", "preorder",
    "postorder", "complexity", "big-o", "big o", "notation", "time",
    "space", "algorithm", "dynamic programming", "greedy", "dp",
    "merge sort", "quick sort", "bubble sort", "insertion sort",
    "selection sort", "heap sort", "binary search", "linear search",
    "avl", "dijkstra", "knapsack", "fibonacci", "lcs", "mst",
    "spanning tree", "topological", "cycle", "adjacency", "matrix",
    "pointer", "node", "edge", "vertex", "lifo", "fifo", "pivot",
    "memoization", "tabulation", "backtracking", "divide", "conquer",
    "hashing", "collision", "chaining", "probing", "priority", "data structure"
}

# ─── Text Preprocessing ───────────────────────────────────────────────────────

def preprocess(text: str) -> list:
    """Lowercase, remove punctuation, tokenize, remove stopwords."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s]", " ", text)
    tokens = text.split()
    return [t for t in tokens if t not in STOPWORDS and len(t) > 1]

def is_ds_question(text: str) -> bool:
    """
    Returns True if the message is likely about Data Structures.
    Uses multi-level detection for best coverage.
    """
    text_lower = text.lower()

    # Direct DS trigger word check
    for trigger in DS_TRIGGER_WORDS:
        if trigger in text_lower:
            return True

    # Check tokenized words against triggers
    tokens = set(preprocess(text))
    for trigger in DS_TRIGGER_WORDS:
        if trigger in tokens:
            return True

    # Check against all knowledge base keywords
    for entry in KNOWLEDGE_BASE:
        for kw in entry.get("keywords", []):
            if kw in text_lower:
                return True

    return False

# ─── TF-IDF Cosine Similarity ─────────────────────────────────────────────────

def _tf(tokens: list) -> dict:
    """Compute term frequency."""
    count = Counter(tokens)
    total = len(tokens) if tokens else 1
    return {word: cnt / total for word, cnt in count.items()}

def _cosine_similarity(vec1: dict, vec2: dict) -> float:
    """Compute cosine similarity between two TF vectors."""
    if not vec1 or not vec2:
        return 0.0
    common = set(vec1) & set(vec2)
    dot = sum(vec1[w] * vec2[w] for w in common)
    mag1 = math.sqrt(sum(v ** 2 for v in vec1.values()))
    mag2 = math.sqrt(sum(v ** 2 for v in vec2.values()))
    if mag1 == 0 or mag2 == 0:
        return 0.0
    return dot / (mag1 * mag2)

# ─── Keyword Overlap Score ────────────────────────────────────────────────────

def _keyword_score(query_tokens: set, entry: dict) -> float:
    """Score based on keyword overlap with entry's keyword list."""
    entry_keywords = set()
    for kw in entry.get("keywords", []):
        entry_keywords.update(kw.lower().split())
    if not entry_keywords:
        return 0.0
    overlap = query_tokens & entry_keywords
    return len(overlap) / max(len(query_tokens), 1)

# ─── Main Matching Function ───────────────────────────────────────────────────

def find_best_match(query: str, top_n: int = 1) -> list:
    """
    Find the best matching knowledge base entry for a given query.
    Uses a combination of:
      1. Keyword overlap
      2. Cosine similarity (TF-based)
      3. Direct question/keyword string match
    Returns a list of (score, entry) tuples sorted by score descending.
    """
    query_lower = query.lower().strip()
    query_tokens_raw = set(preprocess(query))
    query_tf = _tf(list(query_tokens_raw))

    scored = []

    for entry in KNOWLEDGE_BASE:
        score = 0.0

        # 1. Exact/substring match on question
        if entry.get("question", "") in query_lower:
            score += 2.5
        if query_lower in entry.get("question", ""):
            score += 1.5

        # 2. Keyword exact match (full phrase)
        for kw in entry.get("keywords", []):
            if kw in query_lower:
                score += 1.8

        # 3. Keyword token overlap
        score += _keyword_score(query_tokens_raw, entry) * 1.5

        # 4. Cosine similarity with question text
        q_tokens = list(preprocess(entry.get("question", "")))
        q_tf = _tf(q_tokens)
        sim = _cosine_similarity(query_tf, q_tf)
        score += sim * 1.2

        # 5. Bonus for topic word in query
        topic = entry.get("topic", "")
        if topic and topic in query_lower:
            score += 1.0

        if score > 0:
            scored.append((score, entry))

    # Sort by score descending
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[:top_n]

# ─── Public API ───────────────────────────────────────────────────────────────

def get_ds_answer(query: str) -> str | None:
    """
    Returns a DS answer string if a confident match is found,
    otherwise returns None (fall through to normal chatbot).

    Threshold: 0.4 — below this, we're not confident enough.
    """
    if not is_ds_question(query):
        return None

    results = find_best_match(query, top_n=1)
    if not results:
        return _fallback_response(query)

    best_score, best_entry = results[0]

    # Minimum confidence threshold
    if best_score < 0.4:
        return _fallback_response(query)

    return _format_answer(best_entry, best_score)

def _format_answer(entry: dict, score: float) -> str:
    """Format the answer with topic header."""
    topic = entry.get("topic", "").title()
    answer = entry.get("answer", "")
    header = f"📚 **Topic: {topic}**\n\n" if topic else ""
    return header + answer

def _fallback_response(query: str) -> str:
    """Fallback when DS question is detected but no match found."""
    query_lower = query.lower()

    # Try topic-level suggestions
    topic_map = {
        "sort": "sorting algorithms (bubble, merge, quick, heap sort)",
        "tree": "trees (binary tree, BST, AVL, heap)",
        "graph": "graphs (BFS, DFS, Dijkstra, MST)",
        "search": "searching (binary search, linear search, BFS, DFS)",
        "linked": "linked lists (singly, doubly, circular)",
        "stack": "the stack data structure",
        "queue": "the queue data structure",
        "hash": "hash tables and hashing",
        "complex": "time and space complexity / Big-O notation",
        "dp": "dynamic programming",
        "greedy": "greedy algorithms",
        "recursi": "recursion"
    }

    for key, suggestion in topic_map.items():
        if key in query_lower:
            return (
                f"🤔 I'm not sure about the exact details, but I can help with **{suggestion}**!\n\n"
                f"Try asking more specifically, for example:\n"
                f"• 'What is {suggestion.split('(')[0].strip()}?'\n"
                f"• 'Explain {suggestion.split('(')[0].strip()} with example'\n"
                f"• 'What is the time complexity of {suggestion.split('(')[0].strip()}?'"
            )

    return (
        "🤔 I recognize this is a Data Structures question, but I need more context!\n\n"
        "I can explain topics like:\n"
        "• **Arrays, Linked Lists, Stacks, Queues**\n"
        "• **Trees, BST, Graphs, Hash Tables, Heaps**\n"
        "• **Sorting** (Merge, Quick, Bubble, Heap Sort)\n"
        "• **Searching** (Binary Search, BFS, DFS)\n"
        "• **Complexity** (Big-O, Time, Space)\n"
        "• **Dynamic Programming, Greedy Algorithms**\n\n"
        "Try: `What is <topic>?` or `Explain <topic>`"
    )

def get_topic_list() -> str:
    """Returns a formatted list of all available DS topics."""
    topics = sorted(set(e.get("topic", "") for e in KNOWLEDGE_BASE if e.get("topic")))
    lines = [f"• {t.title()}" for t in topics]
    return "📚 **Available DS Topics:**\n\n" + "\n".join(lines) + "\n\nAsk me anything about these topics!"

def get_all_questions() -> list:
    """Returns all questions in the knowledge base."""
    return [e.get("question", "") for e in KNOWLEDGE_BASE]
