import re

INTENT_PATTERNS = {
    "greeting": [r'\b(hi|hello|hey|greetings|howdy|sup|what\'s up)\b'],
    "farewell": [r'\b(bye|goodbye|see you|later|farewell|cya|take care)\b'],
    "question": [r'\b(what|how|why|when|where|who|which|can you|could you|do you|is it|are you|will you)\b', r'\?$'],
    "request": [r'\b(please|can you|could you|would you|help me|i need|i want)\b'],
    "statement": [r'^(i am|i\'m|i have|i feel|i think|i believe|i know)\b'],
    "math": [r'\d+\s*[\+\-\*/\^%]\s*\d+', r'\b(calculate|solve|compute|math)\b'],
    "help": [r'\b(help|guide|assist|support|how to use)\b'],
    "sentiment_positive": [r'\b(love|like|enjoy|happy|great|awesome)\b'],
    "sentiment_negative": [r'\b(hate|dislike|sad|angry|upset|bad)\b'],
}

ENTITY_PATTERNS = {
    "number": r'\b\d+(\.\d+)?\b',
    "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
    "url": r'https?://[^\s]+',
    "date": r'\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\b(january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2})\b',
    "name": r'\bmy name is (\w+)\b',
    "time": r'\b\d{1,2}:\d{2}\s*(am|pm)?\b',
}

def detect_intent(text):
    text_lower = text.lower().strip()
    scores = {}
    for intent, patterns in INTENT_PATTERNS.items():
        score = 0
        for pattern in patterns:
            if re.search(pattern, text_lower):
                score += 1
        if score > 0:
            scores[intent] = score
    if not scores:
        return "unknown"
    return max(scores, key=scores.get)

def extract_entities(text):
    entities = {}
    for entity_type, pattern in ENTITY_PATTERNS.items():
        matches = re.findall(pattern, text, re.IGNORECASE)
        if matches:
            if isinstance(matches[0], tuple):
                matches = [m[0] for m in matches]
            entities[entity_type] = matches
    return entities
