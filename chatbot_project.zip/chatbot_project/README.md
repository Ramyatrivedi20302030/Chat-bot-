# ARIA — Advanced Reasoning & Intelligence Assistant
### National Hackathon Project · Python Flask AI Chatbot

A production-grade AI chatbot with voice, database analytics, and a modern dark-theme UI.

---

## 🚀 Features

| Feature | Description |
|---|---|
| 💬 Smart Chat | Multi-turn conversations with context memory |
| 🧮 Math Solver | Evaluates math expressions in real-time |
| 😊 Sentiment Detection | Detects positive/negative/neutral mood |
| 🎯 Intent Detection | Classifies user intent (question, request, etc.) |
| 🧠 Memory | Remembers your name and conversation history |
| 🎤 Voice Input | Speak to ARIA via microphone |
| 🔊 Text-to-Speech | ARIA speaks her responses aloud |
| 📊 Analytics Dashboard | Charts and stats from MySQL database |
| 🗄️ MySQL Database | All conversations saved via phpMyAdmin |

---

## 📁 Project Structure

```
chatbot_project/
├── app.py               ← Flask server (main entry point)
├── chatbot_core.py      ← Response generation, math solver, sentiment
├── intent_detection.py  ← Intent & entity extraction
├── memory.py            ← In-memory conversation context
├── database.py          ← MySQL connection & queries
├── voice_assistant.py   ← Speech-to-text & text-to-speech
├── requirements.txt     ← Python dependencies
├── templates/
│   ├── index.html       ← Chat UI
│   └── analytics.html   ← Analytics dashboard
└── static/
    ├── style.css        ← Dark futuristic theme
    └── script.js        ← Frontend logic (fetch API)
```

---

## 🛠️ Windows Setup Guide

### Step 1 — Install Python
Download Python 3.10+ from https://python.org  
✅ Check "Add Python to PATH" during installation.

### Step 2 — Install Dependencies

Open **Command Prompt** or **VS Code Terminal** inside the project folder:

```bash
pip install flask
pip install mysql-connector-python
pip install speechrecognition
pip install pyttsx3
pip install pyaudio
```

> ⚠️ If `pyaudio` fails, use:
> ```bash
> pip install pipwin
> pipwin install pyaudio
> ```

### Step 3 — Start WAMP or XAMPP
- Download WAMP: https://www.wampserver.com  
- Or XAMPP: https://www.apachefriends.org  
- Start both **Apache** and **MySQL** services.

### Step 4 — Open phpMyAdmin
Visit: http://localhost/phpmyadmin

### Step 5 — Create Database
- Click **"New"** in the left sidebar  
- Database name: `chatbot_db`  
- Click **Create**

> ✅ The app will auto-create the `conversations` table on first run.

### Step 6 — Configure Database (if needed)
Edit `database.py` if your MySQL credentials differ:
```python
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",       # ← Your MySQL password here
    "database": "chatbot_db"
}
```

### Step 7 — Run the Server
```bash
python app.py
```

You should see:
```
===============================================
  🤖  ARIA - AI Chatbot Server Starting...
===============================================
  Chat UI   →  http://127.0.0.1:5000
  Analytics →  http://127.0.0.1:5000/analytics
===============================================
```

### Step 8 — Open in Browser
- **Chat:** http://127.0.0.1:5000  
- **Analytics:** http://127.0.0.1:5000/analytics

---

## 🗣️ Voice Usage

1. Click the **🎤 microphone button** in the chat UI
2. Speak clearly when the button turns red
3. ARIA will transcribe your speech and respond
4. ARIA will also **speak the response aloud**

> Requires a working microphone and internet (for Google Speech API)

---

## 💡 Example Commands

| You say... | ARIA does... |
|---|---|
| `My name is Alex` | Remembers your name |
| `What is 256 * 48?` | Solves the math |
| `How are you?` | Small talk response |
| `What can you do?` | Lists all features |
| `Show history` | Shows recent chat log |
| `Help` | Shows all commands |
| `Clear memory` | Resets conversation |

---

## 🗄️ Database Schema

```sql
CREATE TABLE conversations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(100),
    user_message TEXT NOT NULL,
    bot_response TEXT NOT NULL,
    intent VARCHAR(50),
    sentiment VARCHAR(20),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

## 📊 Analytics Dashboard

Visit `/analytics` to see:
- Total messages & sessions
- Daily activity bar chart
- Sentiment distribution (donut chart)
- Intent radar chart
- Top user queries (ranked)
- Recent conversation table

---

## 🔧 Troubleshooting

| Problem | Solution |
|---|---|
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` |
| DB connection error | Start WAMP/XAMPP, check `database.py` config |
| Voice not working | Install `pyaudio`, check microphone permissions |
| Port already in use | Kill other Flask processes or change port in `app.py` |

---

## 🏆 Built For
National-level Hackathon · Python Flask · MySQL · Voice AI · Analytics

**Stack:** Python · Flask · MySQL · HTML/CSS/JS · SpeechRecognition · pyttsx3 · Chart.js
