from collections import defaultdict, deque
from datetime import datetime

class ConversationMemory:
    def __init__(self, max_history=20):
        self.max_history = max_history
        self._history = defaultdict(lambda: deque(maxlen=max_history))
        self._user_names = {}
        self._contexts = defaultdict(dict)

    def add(self, session_id, user_msg, bot_msg):
        self._history[session_id].append({
            "user": user_msg,
            "bot": bot_msg,
            "timestamp": datetime.now().isoformat()
        })

    def get_history(self, session_id):
        return list(self._history[session_id])

    def get_context(self, session_id):
        hist = self.get_history(session_id)
        if not hist:
            return ""
        last = hist[-1]
        return f"Previous: User said '{last['user']}', I replied '{last['bot'][:80]}...'"

    def set_user_name(self, session_id, name):
        self._user_names[session_id] = name

    def get_user_name(self, session_id):
        return self._user_names.get(session_id)

    def set_context(self, session_id, key, value):
        self._contexts[session_id][key] = value

    def get_context_value(self, session_id, key):
        return self._contexts[session_id].get(key)

    def clear(self, session_id):
        self._history[session_id].clear()
        self._user_names.pop(session_id, None)
        self._contexts[session_id].clear()

    def get_all_sessions(self):
        return list(self._history.keys())
