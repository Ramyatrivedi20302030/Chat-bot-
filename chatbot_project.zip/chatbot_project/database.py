import mysql.connector
from datetime import datetime

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",          # Default WAMP/XAMPP password is empty
    "database": "chatbot_db"
}

def get_connection():
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        return conn
    except mysql.connector.Error as e:
        print(f"[DB ERROR] Connection failed: {e}")
        return None

def init_db():
    """Create database and table if they don't exist."""
    try:
        conn = mysql.connector.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"]
        )
        cursor = conn.cursor()
        cursor.execute("CREATE DATABASE IF NOT EXISTS chatbot_db")
        cursor.execute("USE chatbot_db")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                session_id VARCHAR(100),
                user_message TEXT NOT NULL,
                bot_response TEXT NOT NULL,
                intent VARCHAR(50),
                sentiment VARCHAR(20),
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        cursor.close()
        conn.close()
        print("[DB] Database initialized successfully.")
    except mysql.connector.Error as e:
        print(f"[DB WARNING] Could not initialize DB: {e}. Running without DB.")

def save_conversation(session_id, user_message, bot_response, intent="unknown", sentiment="neutral"):
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO conversations (session_id, user_message, bot_response, intent, sentiment, timestamp)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (session_id, user_message, bot_response, intent, sentiment, datetime.now()))
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except mysql.connector.Error as e:
        print(f"[DB ERROR] Save failed: {e}")
        return False

def get_analytics():
    conn = get_connection()
    if not conn:
        return get_mock_analytics()
    try:
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT COUNT(*) as total FROM conversations")
        total_msgs = cursor.fetchone()["total"]

        cursor.execute("SELECT COUNT(DISTINCT session_id) as sessions FROM conversations")
        total_sessions = cursor.fetchone()["sessions"]

        cursor.execute("""
            SELECT user_message, COUNT(*) as count
            FROM conversations
            GROUP BY user_message
            ORDER BY count DESC
            LIMIT 10
        """)
        top_queries = cursor.fetchall()

        cursor.execute("""
            SELECT DATE(timestamp) as date, COUNT(*) as count
            FROM conversations
            WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            GROUP BY DATE(timestamp)
            ORDER BY date ASC
        """)
        daily_counts = cursor.fetchall()
        for row in daily_counts:
            row["date"] = str(row["date"])

        cursor.execute("""
            SELECT sentiment, COUNT(*) as count
            FROM conversations
            GROUP BY sentiment
        """)
        sentiment_data = cursor.fetchall()

        cursor.execute("""
            SELECT intent, COUNT(*) as count
            FROM conversations
            GROUP BY intent
            ORDER BY count DESC
        """)
        intent_data = cursor.fetchall()

        cursor.execute("""
            SELECT user_message, bot_response, timestamp
            FROM conversations
            ORDER BY timestamp DESC
            LIMIT 10
        """)
        recent = cursor.fetchall()
        for row in recent:
            row["timestamp"] = str(row["timestamp"])

        cursor.close()
        conn.close()

        return {
            "total_messages": total_msgs,
            "total_sessions": total_sessions,
            "top_queries": top_queries,
            "daily_counts": daily_counts,
            "sentiment_data": sentiment_data,
            "intent_data": intent_data,
            "recent_conversations": recent
        }
    except mysql.connector.Error as e:
        print(f"[DB ERROR] Analytics failed: {e}")
        return get_mock_analytics()

def get_mock_analytics():
    """Return mock data when DB is unavailable."""
    return {
        "total_messages": 0,
        "total_sessions": 0,
        "top_queries": [],
        "daily_counts": [],
        "sentiment_data": [],
        "intent_data": [],
        "recent_conversations": []
    }
