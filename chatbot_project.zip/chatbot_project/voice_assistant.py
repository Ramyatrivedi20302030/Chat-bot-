import threading

def speak(text):
    """Convert text to speech in a non-blocking thread."""
    def _speak():
        try:
            import pyttsx3
            engine = pyttsx3.init()
            engine.setProperty('rate', 175)
            engine.setProperty('volume', 0.9)
            voices = engine.getProperty('voices')
            # Prefer female voice if available
            for voice in voices:
                if 'female' in voice.name.lower() or 'zira' in voice.name.lower():
                    engine.setProperty('voice', voice.id)
                    break
            clean_text = text.replace('**', '').replace('*', '').replace('#', '').replace('`', '')
            engine.say(clean_text)
            engine.runAndWait()
        except Exception as e:
            print(f"[TTS ERROR] {e}")

    t = threading.Thread(target=_speak, daemon=True)
    t.start()

def listen():
    """Listen to microphone and return transcribed text."""
    try:
        import speech_recognition as sr
        recognizer = sr.Recognizer()
        recognizer.energy_threshold = 300
        recognizer.dynamic_energy_threshold = True

        with sr.Microphone() as source:
            print("[Voice] Adjusting for ambient noise...")
            recognizer.adjust_for_ambient_noise(source, duration=0.5)
            print("[Voice] Listening...")
            audio = recognizer.listen(source, timeout=8, phrase_time_limit=10)

        print("[Voice] Processing speech...")
        text = recognizer.recognize_google(audio)
        print(f"[Voice] Recognized: {text}")
        return text

    except ImportError:
        return None
    except Exception as e:
        print(f"[Voice ERROR] {e}")
        return None
